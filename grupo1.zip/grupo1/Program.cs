﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemaBiblioteca
{
    // ==========================================
    // 1. CLASE CATEGORIA
    // ==========================================
    public class Categoria
    {
        public string Id { get; set; }
        public string Nombre { get; set; }

        public Categoria(string id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }
    }

    // ==========================================
    // 2. CLASE LIBRO
    // ==========================================
    public class Libro
    {
        public string CodigoLibro { get; private set; } 
        public string Titulo { get; private set; }
        public string Autor { get; private set; }
        public Categoria CategoriaAsignada { get; private set; }
        public bool EstaDisponible { get; set; }

        public Libro(string codigoLibro, string titulo, string autor, Categoria categoria)
        {
            CodigoLibro = codigoLibro;
            Titulo = titulo;
            Autor = autor;
            CategoriaAsignada = categoria;
            EstaDisponible = true; 
        }
    }

    // ==========================================
    // 3. CLASE USUARIO
    // ==========================================
    public class Usuario
    {
        public string IdUsuario { get; private set; }
        public string Nombre { get; private set; }
        public string Carrera { get; private set; }

        public Usuario(string idUsuario, string nombre, string carrera)
        {
            IdUsuario = idUsuario;
            Nombre = nombre;
            Carrera = carrera;
        }
    }

    // ==========================================
    // 4. CLASE PRESTAMO
    // ==========================================
    public class Prestamo
    {
        public int IdPrestamo { get; private set; }
        public Libro LibroPrestado { get; private set; }
        public Usuario UsuarioSolicitante { get; private set; }
        public DateTime FechaSalida { get; private set; }
        public DateTime? FechaDevolucion { get; private set; }

        public Prestamo(int idPrestamo, Libro libro, Usuario usuario)
        {
            IdPrestamo = idPrestamo;
            LibroPrestado = libro;
            UsuarioSolicitante = usuario;
            FechaSalida = DateTime.Now;
            FechaDevolucion = null; 
        }

        public void FinalizarPrestamo()
        {
            FechaDevolucion = DateTime.Now;
        }
    }

    // ==========================================
    // 5. CLASE LOGICA - BIBLIOTECA
    // ==========================================
    public class Biblioteca
    {
        private List<Libro> libros = new List<Libro>();
        private List<Usuario> usuarios = new List<Usuario>();
        private List<Prestamo> prestamos = new List<Prestamo>();
        private List<Categoria> categorias = new List<Categoria>();
        private int contadorPrestamos = 1;

        public Biblioteca()
        {
            categorias.Add(new Categoria("CAT01", "Ingeniería de Software"));
            categorias.Add(new Categoria("CAT02", "Matemáticas"));
            categorias.Add(new Categoria("CAT03", "Base de Datos"));
        }

        public List<Categoria> ObtenerCategorias() => categorias;

        public bool RegistrarLibro(string codigoLibro, string titulo, string autor, string idCat)
        {
            if (libros.Any(l => l.CodigoLibro == codigoLibro)) return false; // Control de duplicados por código

            var cat = categorias.FirstOrDefault(c => c.Id == idCat);
            if (cat == null) return false;

            libros.Add(new Libro(codigoLibro, titulo, autor, cat));
            return true;
        }

        public bool RegistrarUsuario(string idUsuario, string nombre, string carrera)
        {
            if (usuarios.Any(u => u.IdUsuario == idUsuario)) return false; 

            usuarios.Add(new Usuario(idUsuario, nombre, carrera));
            return true;
        }

        public Libro? BuscarLibroPorCodigo(string codigoLibro)
        {
            return libros.FirstOrDefault(l => l.CodigoLibro == codigoLibro);
        }

        public List<Libro> BuscarLibrosPorTitulo(string titulo)
        {
            return libros.Where(l => l.Titulo.Contains(titulo, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public string RealizarPrestamo(string idUsuario, string codigoLibro)
        {
            var usuario = usuarios.FirstOrDefault(u => u.IdUsuario == idUsuario);
            if (usuario == null) return "Error: El usuario no existe.";

            var libro = libros.FirstOrDefault(l => l.CodigoLibro == codigoLibro);
            if (libro == null) return "Error: El libro no existe.";

            if (!libro.EstaDisponible) return "Error: El libro ya se encuentra prestado.";

            libro.EstaDisponible = false;
            prestamos.Add(new Prestamo(contadorPrestamos++, libro, usuario));
            return "Éxito: Préstamo registrado correctamente.";
        }

        public bool RealizarDevolucion(string codigoLibro)
        {
            var libro = libros.FirstOrDefault(l => l.CodigoLibro == codigoLibro);
            if (libro == null || libro.EstaDisponible) return false;

            var prestamoActivo = prestamos.FirstOrDefault(p => p.LibroPrestado.CodigoLibro == codigoLibro && p.FechaDevolucion == null);
            if (prestamoActivo == null) return false;

            prestamoActivo.FinalizarPrestamo();
            libro.EstaDisponible = true;
            return true;
        }

        public List<Libro> ListarTodosLosLibros() => libros;

        public List<Prestamo> ConsultarPrestamosActivosUsuario(string idUsuario)
        {
            return prestamos.Where(p => p.UsuarioSolicitante.IdUsuario == idUsuario && p.FechaDevolucion == null).ToList();
        }

        public string ObtenerNombreUsuario(string idUsuario)
        {
            var usuario = usuarios.FirstOrDefault(u => u.IdUsuario == idUsuario);
            return usuario != null ? usuario.Nombre : "Usuario Desconocido";
        }
    }

    // ==========================================
    // CLASE PRINCIPAL - INTERFAZ DE CONSOLA (MENU)
    // ==========================================
    class Program
    {
        private static Biblioteca miBiblioteca = new Biblioteca();

        static void Main(string[] args)
        {
            PrecargarDatos();

            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("==================================================");
                Console.WriteLine("      SISTEMA DE GESTIÓN DE BIBLIOTECA - INF-512  ");
                Console.WriteLine("==================================================");
                Console.ResetColor();
                Console.WriteLine("1. Registrar un Libro");
                Console.WriteLine("2. Registrar un Usuario");
                Console.WriteLine("3. Buscar un Libro (por Título)");
                Console.WriteLine("4. Registrar un Préstamo");
                Console.WriteLine("5. Registrar una Devolución");
                Console.WriteLine("6. Consultar Préstamos de un Usuario");
                Console.WriteLine("7. Ver Reporte de Inventario Completo");
                Console.WriteLine("8. Salir");
                Console.WriteLine("--------------------------------------------------");
                Console.Write("Seleccione una opción: ");

                if (!int.TryParse(Console.ReadLine(), out int opcion))
                {
                    MostrarMensajeError("Por favor, ingrese un número válido.");
                    continue;
                }

                switch (opcion)
                {
                    case 1: MenuRegistrarLibro(); break;
                    case 2: MenuRegistrarUsuario(); break;
                    case 3: MenuBuscarLibro(); break;
                    case 4: MenuPrestarLibro(); break;
                    case 5: MenuDevolverLibro(); break;
                    case 6: MenuConsultarUsuario(); break;
                    case 7: MenuReporteCompleto(); break;
                    case 8: salir = true; break;
                    default: MostrarMensajeError("Opción fuera de rango (1-8)."); break;
                }
            }
        }

        static void MenuRegistrarLibro()
        {
            Console.Clear();
            Console.WriteLine("--- REGISTRAR NUEVO LIBRO ---");
            Console.Write("Ingrese Código del Libro: ");
            string codigo = (Console.ReadLine() ?? "").Trim();
            Console.Write("Ingrese Título: ");
            string titulo = (Console.ReadLine() ?? "").Trim();
            Console.Write("Ingrese Autor: ");
            string autor = (Console.ReadLine() ?? "").Trim();

            Console.WriteLine("\nCategorías disponibles:");
            var categorias = miBiblioteca.ObtenerCategorias();
            foreach (var c in categorias)
            {
                Console.WriteLine($"- [{c.Id}] {c.Nombre}");
            }
            Console.Write("Seleccione el ID de la Categoría: ");
            string idCat = (Console.ReadLine() ?? "").Trim().ToUpper();

            if (string.IsNullOrEmpty(codigo) || string.IsNullOrEmpty(titulo) || string.IsNullOrEmpty(autor))
            {
                MostrarMensajeError("Operación cancelada. Los campos no pueden estar vacíos.");
                return;
            }

            if (miBiblioteca.RegistrarLibro(codigo, titulo, autor, idCat))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n¡Libro registrado exitosamente!");
                Console.ResetColor();
            }
            else
            {
                MostrarMensajeError("No se pudo registrar. Verifique si el Código está duplicado o la categoría es inválida.");
            }
            Pausar();
        }
        static void MenuRegistrarUsuario()
    {
    Console.Clear();
    Console.WriteLine("--- REGISTRAR NUEVO USUARIO ---");
    Console.Write("Ingrese ID Universitario (Matrícula): ");
    string id = (Console.ReadLine() ?? "").Trim();
    Console.Write("Ingrese Nombre completo: ");
    string nombre = (Console.ReadLine() ?? "").Trim();
    Console.Write("Ingrese Carrera: ");
    string carrera = (Console.ReadLine() ?? "").Trim();
    if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(nombre))
    {
    MostrarMensajeError("Campos obligatorios vacíos.");
    return;
    }
    if (miBiblioteca.RegistrarUsuario(id, nombre, carrera))
    {
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("\n¡Usuario registrado exitosamente!");
    Console.ResetColor();
    }
    else
    {
    MostrarMensajeError("El ID de usuario ya se encuentra registrado en el sistema.");
    }
    Pausar();
    }
    static void MenuBuscarLibro()
    {
    Console.Clear();
    Console.WriteLine("--- BUSCAR LIBRO ---");
    Console.Write("Ingrese el título o coincidencia a buscar: ");
    string criterio = Console.ReadLine() ?? "";
    var resultados = miBiblioteca.BuscarLibrosPorTitulo(criterio);
    if (resultados.Count == 0)
    {
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("\nNo se encontraron libros que coincidan con la búsqueda.");
    Console.ResetColor();
    }
    else
    {
    Console.WriteLine($"\nResultados encontrados ({resultados.Count}):");
    foreach (var l in resultados)
    {
    string estado = l.EstaDisponible ? "Disponible" : "Prestado";
    Console.WriteLine($"- Código: {l.CodigoLibro} | {l.Titulo} de {l.Autor} [{l.CategoriaAsignada.Nombre}] -> Estado: {estado}");
    }
    }
    Pausar();
    }
    static void MenuPrestarLibro()
    {
    Console.Clear();
    Console.WriteLine("--- PROCESAR PRÉSTAMO ---");
    Console.Write("Ingrese ID del Usuario: ");
    string idUsuario = (Console.ReadLine() ?? "").Trim();
    Console.Write("Ingrese Código del Libro: ");
    string codigo = (Console.ReadLine() ?? "").Trim();
    string resultado = miBiblioteca.RealizarPrestamo(idUsuario, codigo);
    if (resultado.StartsWith("Éxito"))
    {
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine($"\n{resultado}");
    }
    else
    {
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine($"\n{resultado}");
    }
    Console.ResetColor();
    Pausar();
    }
    static void MenuDevolverLibro()
    {
    Console.Clear();
    Console.WriteLine("--- PROCESAR DEVOLUCIÓN ---");
    Console.Write("Ingrese el Código del libro que se va a devolver: ");
    string codigo = (Console.ReadLine() ?? "").Trim();
    if (miBiblioteca.RealizarDevolucion(codigo))
    {
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("\n¡Devolución registrada con éxito! El libro vuelve a estar disponible.");
    }
    else
    {
    MostrarMensajeError("No se procesó la devolución. El libro no existe o no estaba marcado como prestado.");
    }
    Console.ResetColor();
    Pausar();
    }
    static void MenuConsultarUsuario()
    {
    Console.Clear();
    Console.WriteLine("--- CONSULTAR PRÉSTAMOS ACTIVOS DE UN USUARIO ---");
    Console.Write("Ingrese el ID del usuario: ");
    string id = (Console.ReadLine() ?? "").Trim();
    var prestamosActivos = miBiblioteca.ConsultarPrestamosActivosUsuario(id);
    if (prestamosActivos.Count == 0)
    {
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("\nEl usuario no tiene préstamos activos pendientes en este momento.");
    Console.ResetColor();
    }
    else
    {
    string nombreEstudiante = miBiblioteca.ObtenerNombreUsuario(id);
    Console.WriteLine($"\nPréstamos vigentes de {nombreEstudiante}:");
    foreach (var p in prestamosActivos)
    {
    Console.WriteLine($"- Préstamo #{p.IdPrestamo}: '{p.LibroPrestado.Titulo}' (Adquirido: {p.FechaSalida.ToShortDateString()})");
    }
    }
    Pausar();
    }
    static void MenuReporteCompleto()
    {
    Console.Clear();
    Console.WriteLine("==================================================");
    Console.WriteLine("          REPORTE DE INVENTARIO COMPLETO          ");
    Console.WriteLine("==================================================");
    var todos = miBiblioteca.ListarTodosLosLibros();
    if (todos.Count == 0)
    {
    Console.WriteLine("La biblioteca se encuentra vacía de momento.");
    }
    else
    {
    foreach (var l in todos)
    {
    string estado = l.EstaDisponible ? "Disponible" : "PRESTADO";
    Console.WriteLine($"Código: {l.CodigoLibro,-7} | Título: {l.Titulo,-25} | Categoría: {l.CategoriaAsignada.Nombre,-20} | Estado: {estado}");
    }
    }
    Pausar();
    }
    static void PrecargarDatos()
    {
    miBiblioteca.RegistrarLibro("111", "Clean Code", "Robert C. Martin", "CAT01");
    miBiblioteca.RegistrarLibro("222", "C# 12 in a Nutshell", "Joseph Albahari", "CAT01");
    miBiblioteca.RegistrarLibro("333", "Cálculo de una Variable", "James Stewart", "CAT02");
    miBiblioteca.RegistrarUsuario("2024-0001", "Carlos Mendoza", "Ing. de Software");
    miBiblioteca.RegistrarUsuario("2024-0002", "Ana Villanueva", "Ciberseguridad");
    }
    static void MostrarMensajeError(string msg)
    {
    Console.ForegroundColor = ConsoleColor.DarkRed;
    Console.WriteLine($"\n¡Atención! {msg}");
    Console.ResetColor();
    Pausar();
    }
    static void Pausar()
    {
    Console.WriteLine("\nPresione cualquier tecla para continuar...");
    Console.ReadKey();
        }
    }
}
